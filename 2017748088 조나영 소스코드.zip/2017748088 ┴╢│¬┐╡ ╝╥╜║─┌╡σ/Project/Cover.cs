﻿using System;
using System.Windows.Forms;

namespace Project
{
    public partial class Cover : Form
    {
        public Cover()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            // 현재창을 종료하고 두번째 창을 여는 방법 [출처 https://hunit.tistory.com/352]
            this.Visible = false; // 추가
            Contents showContents = new Contents();
            showContents.ShowDialog();
        }
    }
}
