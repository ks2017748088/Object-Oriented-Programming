﻿using System;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace Project
{
    public partial class Result : Form
    {
        public Result()
        {
            InitializeComponent();
            showuser();
            showscore();
            showwant();
        }

        private void showuser ()
        {
            // MySQL에서 데이터 불러오기 [출처 http://pinblog.iptime.org/wordpress/index.php/2019/02/19/csharp-mysql-recieve-data/]
            string source = "Server=localhost;Port=3306;Database=research;Uid=root;password=";
            MySqlConnection con = new MySqlConnection(source);
            MySqlCommand query = con.CreateCommand();
            query.CommandText = "SELECT *";
            query.CommandText += "FROM user";

            try
            {
                con.Open();

                MySqlDataReader reader = query.ExecuteReader();
                dataGridView1.Rows.Clear();

                for (int i = 0; reader.Read(); i++)
                {
                    dataGridView1.Rows.Add();
                    dataGridView1.Rows[i].Cells["grade"].Value = reader["grade"].ToString();
                    dataGridView1.Rows[i].Cells["name"].Value = reader["name"].ToString();
                    dataGridView1.Rows[i].Cells["depart"].Value = reader["depart"].ToString();
                }
            }
            catch (Exception Ex)
            {
                return;
            }
            finally
            {
                con.Close();
            }
        }

        private void showscore()
        {
            // MySQL에서 데이터 불러오기 [출처 http://pinblog.iptime.org/wordpress/index.php/2019/02/19/csharp-mysql-recieve-data/]
            string source = "Server=localhost;Port=3306;Database=research;Uid=root;password=";
            MySqlConnection con = new MySqlConnection(source);
            MySqlCommand query = con.CreateCommand();
            query.CommandText = "SELECT *";
            query.CommandText += "FROM score";

            try
            {
                con.Open();

                MySqlDataReader reader = query.ExecuteReader();
                dataGridView2.Rows.Clear();

                for (int i = 0; reader.Read(); i++)
                {
                    dataGridView2.Rows.Add();
                    dataGridView2.Rows[i].Cells["subject"].Value = reader["subject"].ToString();
                    dataGridView2.Rows[i].Cells["score"].Value = reader["score"].ToString();
                }
            }
            catch (Exception Ex)
            {
                return;
            }
            finally
            {
                con.Close();
            }
        }

        private void showwant()
        {
            // MySQL에서 데이터 불러오기 [출처 http://pinblog.iptime.org/wordpress/index.php/2019/02/19/csharp-mysql-recieve-data/]
            string source = "Server=localhost;Port=3306;Database=research;Uid=root;password=";
            MySqlConnection con = new MySqlConnection(source);
            MySqlCommand query = con.CreateCommand();
            query.CommandText = "SELECT *";
            query.CommandText += "FROM user";

            try
            {
                con.Open();

                MySqlDataReader reader = query.ExecuteReader();
                dataGridView3.Rows.Clear();

                for (int i = 0; reader.Read(); i++)
                {
                    dataGridView3.Rows.Add();
                    dataGridView3.Rows[i].Cells["want"].Value = reader["want"].ToString();
                }
            }
            catch (Exception Ex)
            {
                return;
            }
            finally
            {
                con.Close();
            }
        }
    }
}
