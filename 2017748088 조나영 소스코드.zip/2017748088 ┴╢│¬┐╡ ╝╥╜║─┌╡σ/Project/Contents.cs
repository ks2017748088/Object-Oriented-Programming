﻿using System;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace Project
{
    public partial class Contents : Form
    {
        // DB 주소
        public static string connectionString = "datasource=127.0.0.1;port=3306;username=root;password=;database=research;";
        // 학년값과 점수값 받기
        public static string grade;
        int[] score = new int[20];
        

        public Contents()
        {
            InitializeComponent();
            // 판넬에 넣은 것을 보여주는 함수
            show_sub();
        }

        private void show_sub()
        {
            // 클릭 할 때마다 카운터가 늘어남
            for (int i = 0; i < AddSub.clickcount; i++)
            {
                // 두번 클릭하면 두번 들어가게 함
                panel2.Controls.Add(AddSub.panel[i]);
            }
        }

        private void SaveScore ()
        {
            // 테이블에 데이터 입력하기 INSERT INTO [출처 https://lightblog.tistory.com/142]
            // 과목이 여러개라서 for문을 씀
            for (int i = 0; i < AddSub.clickcount; i++)
            {
                Savedb("INSERT INTO score(`subject`, `score`) VALUES ('" + AddSub.subject[i].Text + "', '" + score[i] + "')");
            }   
        }

        private void SaveUser ()
        {
            // 테이블에 데이터 입력하기 INSERT INTO [출처 https://lightblog.tistory.com/142]
            // 하나이기 때문에 굳이 for문을 쓰지 않아도 됨
            Savedb("INSERT INTO user(`grade`, `name`, `depart`,`want`) VALUES ('" + grade + "', '" + textBox1.Text + "', '" + textBox2.Text + "', '"+ textBox8.Text +"')");
        }

        private void Savedb(string query)
        {
            // DB에 업로드 [출처 https://ourcodeworld.com/articles/read/218/how-to-connect-to-mysql-with-c-sharp-winforms-and-xampp]
            MySqlConnection databaseConnection = new MySqlConnection(connectionString);
            MySqlCommand commandDatabase = new MySqlCommand(query, databaseConnection);
            commandDatabase.CommandTimeout = 60;

            try
            {
                databaseConnection.Open();
                MySqlDataReader myReader = commandDatabase.ExecuteReader();

                //MessageBox.Show("User succesfully registered");

                databaseConnection.Close();
            }
            catch (Exception ex)
            {
                // Show any error message.
                MessageBox.Show(ex.Message);
            }
        }

        private void gradechecked()
        {
            // radioButton의 체크 상태 활성화 유무 [출처 https://076923.github.io/posts/C-5/]
            if (radioButton1.Checked == true) grade = "1";
            else if (radioButton2.Checked == true) grade = "2";
            else if (radioButton3.Checked == true) grade = "3";
            else if (radioButton4.Checked == true) grade = "4";
            else grade = "미선택";
        } 

        private void scorechecked()
        {
            AddSub.clickcount -= 1;

            for (int i = 0; i < 5 + (AddSub.clickcount * 5); i++)
            {
                for (int j = 0; j < 5; j++)
                {
                    if (AddSub.mark[i+j].Checked == true)
                    {
                        // char를 int로 자료형 변환 [출처 https://www.delftstack.com/ko/howto/csharp/how-to-convert-character-to-integer-in-csharp/]
                        score[(i + j) / 5] = (int)char.GetNumericValue(AddSub.mark[i+j].Text[0]);
                    }
                }
                i = i + 4;
            }
            AddSub.clickcount += 1;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            // 현재창을 종료하고 두번째 창을 여는 방법 [출처 https://hunit.tistory.com/352]
            this.Visible = false; // 추가
            AddSub showAddSub = new AddSub();
            showAddSub.ShowDialog();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            gradechecked();
            scorechecked();

            SaveUser();
            SaveScore();
            // 현재창을 종료하고 두번째 창을 여는 방법 [출처: https://hunit.tistory.com/352]
            this.Visible = false; // 추가
            Result showResult = new Result();
            showResult.ShowDialog();
        }
    }
}
