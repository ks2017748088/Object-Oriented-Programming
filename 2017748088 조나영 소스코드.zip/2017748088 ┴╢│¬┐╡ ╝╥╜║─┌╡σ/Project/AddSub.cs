﻿using System;
using System.Windows.Forms;
using System.Drawing;

namespace Project
{
    public partial class AddSub : Form
    {
        public static Label[] subject = new Label[20];
        public static FlowLayoutPanel[] panel = new FlowLayoutPanel[20];
        public static RadioButton[] mark = new RadioButton[100];
        public static int clickcount;
     
        public AddSub()
        {
            InitializeComponent();
        }

        private void save_sub()
        {
            // 임의의 갯수의 텍스트박스를 생성하여 패널에 그리기 [출처 https://www.hobbiez.ml/archives/175]
            // 동적으로 버튼을 추가하며 각 버튼을 클릭했을 때의 클릭 수를 화면에 표시 
            // [출처 http://ehpub.co.kr/windows-forms-%EC%9D%91%EC%9A%A9-with-c-2-1-%EB%8F%99%EC%A0%81%EC%9C%BC%EB%A1%9C-%EB%B2%84%ED%8A%BC-%EC%83%9D%EC%84%B1-%EC%8B%A4%EC%8A%B5/]
            if (1 <= clickcount && clickcount < 20)
            {
                clickcount = clickcount - 1;

                // 클릭할 때마다 subject Label 추가
                subject[clickcount] = new Label();
                subject[clickcount].Size = new Size(150, 20);
                subject[clickcount].Text = textBox1.Text;
                subject[clickcount].AutoSize = false;

                panel[clickcount] = new FlowLayoutPanel();
                panel[clickcount].Size = new Size(600, 40);
                panel[clickcount].Location = new Point(0, 20 + (clickcount * 40));

                panel[clickcount].Controls.Add(subject[clickcount]);

                for (int i = 0; i < 5; i++)
                {
                    // 체크박스 동시에 5개 만들어서 panel에 추가
                    mark[i + (5 * clickcount)] = new RadioButton();
                    mark[i + (5 * clickcount)].Size = new Size(60, 20);
                    if ((clickcount * 5) == 0)
                    {
                        mark[i + (5 * clickcount)].Text = (i + 1).ToString() + "점";
                    }
                    else if (i + (5 * clickcount) % (clickcount * 5) == 0)
                    {
                        mark[i + 5 * clickcount].Text = "1점";
                    }
                    else
                    {
                        mark[i + (5 * clickcount)].Text = (i + 1).ToString() + "점";
                    }
                    panel[(i + 5 * clickcount) / 5].Controls.Add(mark[i + (5 * clickcount)]);
                }
            }
            clickcount = clickcount + 1;
        }
   
        private void button1_Click(object sender, EventArgs e)
        {
            // button1을 클릭할 때마다 count 늘어나기
            clickcount++;
            // panel에 저장
            save_sub();
            MessageBox.Show("추가되었습니다.");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            // 현재창을 종료하고 두번째 창을 여는 방법 [출처 https://hunit.tistory.com/352]
            this.Visible = false; // 추가
            Contents showContents = new Contents();
            showContents.ShowDialog();
        }
    }
}
